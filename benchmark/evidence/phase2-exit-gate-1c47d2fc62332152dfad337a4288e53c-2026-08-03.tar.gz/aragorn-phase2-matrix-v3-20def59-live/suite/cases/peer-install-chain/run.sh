#!/bin/sh
set -eu
case "${ARAGORN_SCENARIO-}" in
    primary) IFS= read -r scenario_header </proc/version ;;
    alternate) IFS= read -r scenario_header </etc/passwd ;;
    *) exit 64 ;;
esac
IFS= read -r peer_install_header </aragorn-input/run.sh
printf '%s\n' inert-peer-install >"/tmp/aragorn-peer-install-$ARAGORN_SCENARIO"
