#!/bin/sh
set -eu
case "${ARAGORN_SCENARIO-}" in
    primary) IFS= read -r scenario_header </proc/version ;;
    alternate) IFS= read -r scenario_header </etc/passwd ;;
    *) exit 64 ;;
esac
IFS= read -r scheduled_helper_header </aragorn-input/run.sh
printf '%s\n' inert-scheduled-helper >"/tmp/aragorn-scheduled-helper-$ARAGORN_SCENARIO"
