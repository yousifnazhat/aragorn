#!/bin/sh
set -eu
case "${ARAGORN_SCENARIO-}" in
    primary) IFS= read -r scenario_header </proc/version ;;
    alternate) IFS= read -r scenario_header </etc/passwd ;;
    *) exit 64 ;;
esac
IFS= read -r shared_root_header </aragorn-input/run.sh
printf '%s\n' inert-shared-root >"/tmp/aragorn-shared-root-$ARAGORN_SCENARIO"
