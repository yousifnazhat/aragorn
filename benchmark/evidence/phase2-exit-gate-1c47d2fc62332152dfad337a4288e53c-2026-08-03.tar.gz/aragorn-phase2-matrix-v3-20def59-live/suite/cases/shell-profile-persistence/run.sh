#!/bin/sh
set -eu
case "${ARAGORN_SCENARIO-}" in
    primary) IFS= read -r scenario_header </proc/version ;;
    alternate) IFS= read -r scenario_header </etc/passwd ;;
    *) exit 64 ;;
esac
IFS= read -r shell_profile_header </aragorn-input/run.sh
printf '%s\n' inert-shell-profile >"/tmp/aragorn-shell-profile-$ARAGORN_SCENARIO"
