#!/bin/sh
set -eu
case "${ARAGORN_SCENARIO-}" in
    primary) IFS= read -r scenario_header </proc/version ;;
    alternate) IFS= read -r scenario_header </etc/passwd ;;
    *) exit 64 ;;
esac
IFS= read -r zero_width_header </aragorn-input/run.sh
printf '%s\n' inert-zero-width >"/tmp/aragorn-zero-width-$ARAGORN_SCENARIO"
